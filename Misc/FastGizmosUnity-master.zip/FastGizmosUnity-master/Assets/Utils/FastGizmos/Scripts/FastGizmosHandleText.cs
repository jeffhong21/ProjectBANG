﻿//FastGizmos Tool by SVerde
//contact@sverdegd.com
//https://github.com/sverdegd

using UnityEngine;

namespace SVerdeTools.FastGizmos
{
    public class FastGizmosHandleText : MonoBehaviour
    {
        public bool enable = true;
        public string text = string.Empty;
    }
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Mochineko.SimpleReorderableList.Samples
{
	public class SinglePropertySample : MonoBehaviour
	{
		[SerializeField]
		private string[] texts = new string[0];
	}
}

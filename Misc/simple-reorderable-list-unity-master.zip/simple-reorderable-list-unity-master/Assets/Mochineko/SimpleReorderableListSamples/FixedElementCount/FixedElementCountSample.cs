﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Mochineko.SimpleReorderableList.Samples
{
	public class FixedElementCountSample : MonoBehaviour
	{
		[SerializeField]
		private string[] texts = new string[5];
	}
}

Unity Animation Hierarchy Editor
================================

This utility will help you refactor your Unity animations.

Place the AnimationHierarchyEditor.cs file in YourProject/Editors/ folder to make it work. Then you'll be able to open Animation Hierarchy Editor window by clicking on Window > Animation Hierarchy Editor.

The editor will work if you select an animation clip.
